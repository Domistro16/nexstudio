from __future__ import annotations
import base64,hashlib,json,mimetypes,shutil
from copy import deepcopy
from pathlib import Path
from typing import Any

HERE=Path(__file__).resolve().parent
BASE=HERE.parents[0]
VERSION='2.0.0'
STAGE='NEXSTUDIO_EDITORIAL_EXECUTION_BODY_V2'

def stable(x:Any)->str:
    return hashlib.sha256(json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()).hexdigest()

def _sha(p:Path)->str:
    return hashlib.sha256(p.read_bytes()).hexdigest()

def _data_uri(p:Path)->str:
    mime=mimetypes.guess_type(p.name)[0] or ('image/svg+xml' if p.suffix.lower()=='.svg' else 'application/octet-stream')
    return f"data:{mime};base64,{base64.b64encode(p.read_bytes()).decode('ascii')}"

def _asset_source(binding:dict)->Path|None:
    source_class=binding.get('sourceClass')
    source_path=binding.get('sourcePath')
    if source_class in {'AEV1_CURATED_200','FPR_SEMANTIC_PRIMITIVES_V1'} and source_path:
        p=BASE/str(source_path)
        return p if p.exists() else None
    return None

def write_renderer_package(execution:dict,outdir:Path|str)->dict:
    """Package an already-authored P8 Editorial render program.

    This module is execution-only. It does not compile Story, Visual Concept,
    Art Direction, camera or motion choices and has no import path to the old
    Faceless Level1-4 creative stack.
    """
    if execution.get('blocked'):
        raise RuntimeError('cannot render blocked Editorial execution plan')
    rp=deepcopy(execution['renderProgram'])
    out=Path(outdir);out.mkdir(parents=True,exist_ok=True);(out/'assets').mkdir(exist_ok=True)
    amap={}
    for b in rp.get('assets') or []:
        src=_asset_source(b)
        if src:
            if b.get('sha256') and _sha(src)!=b.get('sha256'):
                raise RuntimeError('EDITORIAL_EXECUTION_ASSET_HASH_CHANGED')
            dst=out/'assets'/f"{b['assetId']}{src.suffix or '.svg'}";shutil.copy2(src,dst);amap[b['assetId']]=_data_uri(dst)
        elif b.get('sourceClass')=='CUSTOMER_MEDIA':
            sp=Path(str(b.get('sourcePath') or ''))
            if not sp.exists() or not sp.is_file() or (b.get('sha256') and _sha(sp)!=b.get('sha256')):
                raise RuntimeError('EDITORIAL_CUSTOMER_MEDIA_MISSING_OR_CHANGED')
            dst=out/'assets'/('customer-'+sp.name);shutil.copy2(sp,dst);amap[b['assetId']]=_data_uri(dst)
        else:
            amap[b['assetId']]=None
    for scene in rp.get('scenes') or []:
        for b in scene.get('assetBindings') or []:
            b['renderSrc']=amap.get(b.get('assetId'))
    for b in rp.get('assets') or []:
        b['renderSrc']=amap.get(b.get('assetId'))
    (out/'render-plan.json').write_text(json.dumps(rp,indent=2,ensure_ascii=False)+'\n')
    engine=(BASE/'renderer/faceless-level5-engine.js').read_text()
    css=(BASE/'renderer/faceless-level5.css').read_text()
    safe=json.dumps(rp,ensure_ascii=False).replace('</','<\\/')
    doc=f'''<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>NexStudio Editorial Execution</title><style>{css}</style></head><body><main id="nex-root" aria-label="NexStudio Editorial render"><div id="nex-stage"></div></main><script id="nex-plan" type="application/json">{safe}</script><script>{engine}</script></body></html>'''
    (out/'render.html').write_text(doc)
    return {'renderHtml':str((out/'render.html').resolve()),'renderPlan':str((out/'render-plan.json').resolve()),'assetCount':len(amap),'duration':rp['duration'],'ratio':rp['ratio'],'digest':stable(rp)}

__all__=['write_renderer_package','stable']
