# SOURCE RESEARCH DECISION

The acquisition pass reviewed the permissive/open sources already identified for NexStudio: Tabler/Iconify, Lucide, Microsoft Fluent Emoji, Web3 Icons, Open Doodles/Open Peeps, Kenney, Poly Haven/ambientCG and permissive motion/data libraries.

Before downloading another broad icon batch, the connected NexStudio Library was audited. It already contained a **locked 242-asset Object World** (180 semantic icons, 36 literal props, 18 metaphors, 8 environment fragments) plus a **66-asset character system** and current specialist mechanism heroes.

Therefore this pack does **not** import 200 near-duplicate public icons. It curates the 200 most immediately useful, provenance-safe files already available, deduplicates exact geometry by SHA-256, and labels them for autonomous Explainer retrieval. External libraries remain the gap-fill sources when future stress tests identify a missing semantic object.

This reduces asset sprawl, licence work and Director ambiguity while preserving a much larger future acquisition pool.
