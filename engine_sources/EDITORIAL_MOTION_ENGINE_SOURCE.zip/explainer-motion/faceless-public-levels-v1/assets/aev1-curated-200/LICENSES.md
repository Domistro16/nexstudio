# LICENSING & PROVENANCE

This curated pack deliberately excludes licence-uncertain or trademark-sensitive third-party brand assets.

## Included source classes
- **NexStudio-authored/internal** — original project assets created inside the NexStudio build lineage.
- **Open Doodles / CC0 1.0** — eight selected whole-action human illustrations normalized by NexStudio; source provenance was already recorded in the Phase 2 character registry.

## Explicitly not included
- Freepik contextual hero scenes whose production entitlement/evidence remains unresolved.
- Rive marketplace specimens used for engineering reference.
- Lottie marketplace animations.
- Web3/AI/company/protocol logos with trademark considerations.

Brand marks should be user-supplied or separately verified per production.
