# NexStudio Autonomous Explainer V1 — Curated Production Asset 200

**Assets:** 200 unique SVG files.

This is the first closed production vocabulary for the safer autonomous Explainer direction: reusable icon/object compositions, reusable AI/Crypto mechanisms, infographic/data beats, product-media beats and restrained character support.

## Structure
- `assets/icons/` — semantic symbols, including full selected AI and Crypto vocabularies
- `assets/objects/props/` — literal physical/digital objects
- `assets/objects/metaphors/` — reusable visual metaphors
- `assets/environments/` — character-free staging fragments
- `assets/characters/` — selected reusable whole-action/support people
- `assets/mechanisms/` — specialist causal hero SVGs
- `manifest.json` — runtime-ready metadata
- `ASSET_INDEX.csv` — human-readable inventory
- `SCENARIO_COVERAGE.json` — first-pass likely AI/Crypto/product scenario mapping
- `LICENSES.md` — provenance boundary

## Director rule
Treat this pack as a **closed certified vocabulary**, not a requirement to use an icon for every beat. Preferred order: certified scenario/mechanism → icon/object composition → infographic/data → product media → kinetic typography → truthful abstract fallback.

## Motion rule
No idle bobbing, generic orbiting, floating icon clouds or decorative connector webs. Motion must be owned by the beat: reveal, nudge, dock, transfer, state-change, count, highlight, match-position, or causal mechanism performance.
