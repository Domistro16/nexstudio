(()=>{"use strict";
const plan=JSON.parse(document.getElementById('nex-plan').textContent),stage=document.getElementById('nex-stage');
const clamp=(v,a=0,b=1)=>Math.max(a,Math.min(b,v)),lerp=(a,b,t)=>a+(b-a)*t,ease=t=>t<.5?2*t*t:1-Math.pow(-2*t+2,2)/2;
const ratio=plan.ratio, dims=ratio==='16:9'?[1280,720]:ratio==='1:1'?[900,900]:[720,1280];
const artDefaults={spatial_mode:'FLAT_CANVAS',depth_mode:'LAYERED',hero_scale:'LARGE',environment_density:'MINIMAL',overlap_mode:'NONE',typography_mode:'SUPPORT'};
function artDirectives(scene){return Object.assign({},artDefaults,scene?.composition?.executionDirectives||{})}
const resizeSlot=(q,m)=>[q[0],q[1],Math.min(.92,q[2]*m),Math.min(.92,q[3]*m)];
stage.style.setProperty('--vw',dims[0]);stage.style.setProperty('--vh',dims[1]);document.documentElement.style.setProperty('--bg',plan.brand.background);document.documentElement.style.setProperty('--ink',plan.brand.ink);document.documentElement.style.setProperty('--surface',plan.brand.surface);document.documentElement.style.setProperty('--primary',plan.brand.primary);document.documentElement.style.setProperty('--accent',plan.brand.accent);document.documentElement.style.setProperty('--secondary',plan.brand.secondary);
function activeScenes(t){let xs=plan.scenes.filter(x=>t>=x.start&&t<x.end);if(!xs.length)xs=[t>=plan.duration?plan.scenes.at(-1):plan.scenes[0]];return xs}
function geom(scene){const bp=scene.blueprintId||'',fam=scene.familyId||'',R=ratio==='9:16';let hero=[.5,.53,.36,.52],supports=[];
 if(bp==='human.handoff-diagonal'||bp==='human.shared-task-stage'){hero=[.5,.55,R?.32:.25,R?.25:.25];supports=R?[[.5,.26,.42,.32],[.5,.82,.42,.32]]:[[.21,.55,.33,.55],[.79,.55,.33,.55]]}
 else if(bp==='human.action-zone'||bp==='hero.character-object'){hero=R?[.5,.66,.42,.40]:[.60,.56,.30,.45];supports=R?[[.5,.27,.50,.34]]:[[.24,.55,.38,.58],[.83,.40,.18,.28]]}
 else if(bp==='human.over-shoulder-evidence'){hero=R?[.5,.35,.52,.42]:[.30,.53,.34,.55];supports=R?[[.5,.76,.46,.28]]:[[.70,.52,.42,.52]]}
 else if(fam==='family.physical-spatial-mechanism'){hero=R?[.5,.38,.30,.22]:[.35,.52,.20,.30];supports=R?[[.5,.62,.68,.42],[.5,.86,.28,.18]]:[[.58,.58,.58,.48],[.84,.54,.20,.28]]}
 else if(fam==='family.comparison-decision'){hero=[.5,.48,R?.45:.25,R?.25:.30];supports=R?[[.5,.25,.45,.24],[.5,.76,.45,.24]]:[[.23,.58,.34,.46],[.77,.58,.34,.46]]}
 else if(fam==='family.evidence-data-reveal'){hero=[.5,.54,R?.66:.46,R?.42:.58];supports=R?[[.5,.82,.44,.22]]:[[.80,.50,.26,.34]]}
 else if(fam==='family.editorial-typography'){hero=R?[.5,.42,.78,.28]:[.38,.46,.58,.32];supports=R?[[.5,.69,.56,.20],[.5,.84,.42,.15],[.5,.18,.34,.16]]:[[.78,.40,.30,.30],[.78,.72,.30,.26],[.23,.78,.28,.20]]}
 else if(fam==='family.spatial-system'){hero=[.5,.52,R?.46:.30,R?.30:.42];supports=R?[[.5,.24,.38,.22],[.5,.80,.38,.22]]:[[.18,.45,.23,.30],[.82,.45,.23,.30],[.5,.83,.22,.24]]}
 else if(fam==='family.object-transformation'){hero=[.5,.55,R?.58:.38,R?.38:.55];supports=R?[[.5,.20,.30,.20]]:[[.18,.55,.22,.30],[.82,.55,.22,.30]]}
 else if(fam==='family.product-in-context'){hero=[.5,.53,R?.68:.48,R?.46:.66];supports=R?[[.5,.83,.36,.20]]:[[.82,.58,.22,.30]]}
 else if(fam==='family.hero-emotional'){hero=[.5,.55,R?.58:.40,R?.42:.62];supports=R?[[.5,.22,.34,.22]]:[[.80,.45,.24,.34]]}
 const ad=artDirectives(scene);
 const hm=ad.hero_scale==='DOMINANT_CLOSE'?1.28:ad.hero_scale==='MEDIUM'?.88:1.08;hero=resizeSlot(hero,hm);
 if(ad.spatial_mode==='GROUNDED_SCENE'){hero[1]=Math.max(hero[1],ratio==='9:16'?.60:.58);supports=supports.map((q,i)=>[q[0],Math.max(q[1],ratio==='9:16'?.31:.38),q[2],q[3]])}
 else if(ad.spatial_mode==='PRODUCT_STAGE'){hero[0]=.5;hero[1]=.54;supports=supports.map((q,i)=>ratio==='9:16'?[.5,i%2?.82:.22,q[2],q[3]]:[i%2?.80:.20,.58,q[2],q[3]])}
 else if(ad.spatial_mode==='INFORMATION_SPACE'){hero[0]=ratio==='9:16'?.5:.36;supports=supports.map((q,i)=>ratio==='9:16'?[.5,.72+i*.08,q[2],q[3]]:[.76,.34+i*.22,q[2],q[3]])}
 if(ad.depth_mode==='FLAT')supports=supports.map(q=>resizeSlot(q,.92));
 else if(ad.depth_mode==='DEEP')supports=supports.map((q,i)=>resizeSlot(q,i%2?1.05:.82));
 if(supports.length&&ad.overlap_mode==='HERO_SUPPORT'){supports[0]=[hero[0]+(ratio==='9:16'?0:.22),hero[1]+.08,supports[0][2],supports[0][3]]}
 else if(supports.length&&ad.overlap_mode==='PURPOSEFUL_FOREGROUND'){const i=supports.length-1;supports[i]=resizeSlot([ratio==='9:16'?.5:.72,ratio==='9:16'?.84:.78,supports[i][2],supports[i][3]],1.18)}
 return {hero,supports,directives:ad};}
function node(binding,slot,scene,u,index){const el=document.createElement('div');const variant=Number(binding.identityVariant||0)%5,ad=artDirectives(scene);el.className='semantic-node role-'+binding.role+' identity-v'+variant+' type-mode-'+String(ad.typography_mode||'SUPPORT').toLowerCase()+' density-'+String(ad.environment_density||'MINIMAL').toLowerCase()+' depth-'+String(ad.depth_mode||'LAYERED').toLowerCase();el.dataset.continuityId=binding.continuityId;el.dataset.semanticEntityId=binding.semanticEntityId;el.dataset.assetId=binding.assetId;el.dataset.role=binding.role;el.dataset.kind=binding.kind||'';el.dataset.identityVariant=String(variant);el.dataset.semantic='true';el.id='cid-'+binding.continuityId.replace(/[^a-z0-9_-]/gi,'_');
 const [x,y,w,h]=slot;el.style.left=(x*100)+'%';el.style.top=(y*100)+'%';el.style.width=(w*100)+'%';el.style.height=(h*100)+'%';
 if(binding.rendererMode==='semantic-typography'){const tx=document.createElement('div');tx.className='semantic-type';tx.textContent=scene.displayCopy||binding.semanticEntityId;el.appendChild(tx)}else{const img=document.createElement('img');img.alt='';img.draggable=false;img.src=binding.renderSrc||'';el.appendChild(img)}
 const m=scene.motion||{},pid=m.performerId,spatial=(m.spatialTargetContinuityIds||[]).includes(binding.continuityId),isTarget=(m.targetContinuityIds||[]).includes(binding.continuityId);let tx=0,ty=0,sc=1,rot=0,op=1;
 if(isTarget){const q=ease(u),pulse=Math.sin(Math.PI*q),towardX=x<.5?1:x>.5?-1:0,towardY=y<.5?1:y>.5?-1:0;
  if(pid==='LMP-INSPECT-EMPHASIS')sc=1+.08*pulse;
  else if(pid==='LMP-PICK-PLACE'){if(spatial){tx=towardX*12*pulse;ty=towardY*8*pulse}else if(binding.role==='hero')sc=1-.045*pulse}
  else if(pid==='LMP-INSERT-EXTRACT'){if(spatial){tx=towardX*12*pulse;ty=towardY*10*pulse}if(binding.role==='hero'){sc=1-.10*pulse;op=1-.10*pulse}}
  else if(pid==='LMP-HANDOFF-CONTACT'&&spatial){if(binding.kind==='actor'){/* local reach only */}else if(ratio==='9:16')ty=lerp(-14,14,q);else tx=lerp(-16,16,q)}
  else if(pid==='LMP-CARRY-WALK'&&spatial)tx=lerp(-7,7,q);
  else if(pid==='LMP-STATE-CHANGE'){const a=scene.semanticAction||'';if(a==='press'||a==='tap')sc=1-.12*pulse;else if(a==='open')rot=6*pulse;else if(a==='close')rot=-5*pulse;else if(a==='choose')sc=1+.10*q;else if(a==='operate'&&spatial)tx=lerp(-18,18,q);else sc=1-.045*pulse}
  else if(pid==='LMP-COUNT-EVIDENCE')sc=1+.06*pulse;
  else if(pid==='LMP-COMPARE-DECIDE')sc=1+(index%2===0?.055:-.02)*pulse}
 el.style.transform=`translate(-50%,-50%) translate(${tx}%,${ty}%) rotate(${rot}deg) scale(${sc})`;el.style.opacity=op;return el}

function typographySlot(scene){const ad=artDirectives(scene),R=ratio==='9:16';
 if(ad.typography_mode==='HERO')return R?[.5,.22,.82,.26]:[.5,.18,.82,.23];
 if(ad.typography_mode==='EMBEDDED'){
  if(ad.spatial_mode==='PRODUCT_STAGE')return R?[.5,.90,.78,.12]:[.5,.88,.72,.12];
  if(ad.spatial_mode==='GROUNDED_SCENE')return R?[.5,.13,.78,.13]:[.24,.16,.36,.15];
  return R?[.5,.84,.76,.13]:[.5,.84,.62,.13];
 }
 return R?[.5,.14,.78,.16]:[.24,.16,.40,.17];}
function sceneU(s,t){return clamp((t-s.start)/Math.max(.001,s.duration))}
function motionSceneFor(active,cid,fallback){const xs=active.filter(s=>(s.motion?.targetContinuityIds||[]).includes(cid));if(!xs.length)return fallback;xs.sort((a,b)=>{const as=(a.motion?.spatialTargetContinuityIds||[]).includes(cid)?2:(a.motion?.performerId!=='LMP-STATIC-HOLD'?1:0),bs=(b.motion?.spatialTargetContinuityIds||[]).includes(cid)?2:(b.motion?.performerId!=='LMP-STATIC-HOLD'?1:0);return bs-as||b.start-a.start});return xs[0]}
function renderAt(t){t=clamp(+t||0,0,plan.duration);const active=activeScenes(t),s=active[0],u=sceneU(s,t);stage.replaceChildren();stage.dataset.sceneId=active.map(x=>x.sceneId).join('+');stage.dataset.eventId=active.map(x=>x.eventId).join('+');stage.dataset.activeEventIds=active.map(x=>x.eventId).join(',');stage.dataset.blueprintId=s.blueprintId;stage.dataset.treatment=s.treatmentClass;
 const world=document.createElement('section');const g=geom(s);world.className='semantic-world spatial-'+String(g.directives.spatial_mode||'FLAT_CANVAS').toLowerCase()+' depth-'+String(g.directives.depth_mode||'LAYERED').toLowerCase()+' density-'+String(g.directives.environment_density||'MINIMAL').toLowerCase();world.dataset.rendererLayer='semantic-world';world.dataset.spatialMode=g.directives.spatial_mode;world.dataset.depthMode=g.directives.depth_mode;world.dataset.environmentDensity=g.directives.environment_density;world.dataset.overlapMode=g.directives.overlap_mode;world.dataset.typographyMode=g.directives.typography_mode;const heroCid=s.storyResponsibility.heroContinuityId,merged=new Map();for(const as of active){for(const b of as.assetBindings){if(!merged.has(b.continuityId))merged.set(b.continuityId,{binding:b,sourceScene:as})}}
 const ordered=[...merged.values()].sort((a,b)=>a.binding.continuityId===heroCid?-1:b.binding.continuityId===heroCid?1:0);let si=0;ordered.forEach((entry,i)=>{const b=entry.binding,ms=motionSceneFor(active,b.continuityId,entry.sourceScene),mu=sceneU(ms,t);let slot;if(b.continuityId===heroCid)slot=g.hero;else if(b.rendererMode==='semantic-typography')slot=typographySlot(ms);else slot=(g.supports[si++]||[.5,.80,.24,.24]);world.appendChild(node(b,slot,ms,mu,i))});stage.appendChild(world);
 const camScene=[...active].reverse().find(x=>x.camera?.motivated)||s,cam=camScene.camera||{};let cx=0,cy=0,cs=1;if(cam.motivated){const q=ease(sceneU(camScene,t));cs=lerp(cam.scaleStart||1,cam.scaleEnd||1,q);const mode=String(cam.atom||cam.mode||'').toUpperCase();const target=cam.targetContinuityId?world.querySelector(`[data-continuity-id="${CSS.escape(cam.targetContinuityId)}"]`):null;if(target&&['REFRAME','PAN','TILT','TRACK','FOLLOW'].includes(mode)){const px=parseFloat(target.style.left)||50,py=parseFloat(target.style.top)||50;const amount=cam.intensity==='STRONG'?.34:cam.intensity==='MODERATE'?.26:.18;const dx=(50-px)*amount,dy=(50-py)*amount;if(mode==='PAN')cx=lerp(0,dx,q);else if(mode==='TILT')cy=lerp(0,dy,q);else{cx=lerp(0,dx,q);cy=lerp(0,dy,q);}}else{cx=lerp((cam.offsetStart||[0,0])[0]||0,(cam.offsetEnd||[0,0])[0]||0,q);cy=lerp((cam.offsetStart||[0,0])[1]||0,(cam.offsetEnd||[0,0])[1]||0,q)}}world.style.transform=`translate(${cx}%,${cy}%) scale(${cs})`;
 return probe(t)}
function probe(t=0){const visible=[...stage.querySelectorAll('.semantic-node')].map(n=>({continuityId:n.dataset.continuityId,semanticEntityId:n.dataset.semanticEntityId,assetId:n.dataset.assetId,role:n.dataset.role,kind:n.dataset.kind,identityVariant:n.dataset.identityVariant,transform:n.style.transform,rect:(()=>{const r=n.getBoundingClientRect();return [r.x,r.y,r.width,r.height]})()}));const ids=visible.map(x=>x.continuityId);return {time:t,sceneId:stage.dataset.sceneId,eventId:stage.dataset.eventId,activeEventIds:(stage.dataset.activeEventIds||'').split(',').filter(Boolean),blueprintId:stage.dataset.blueprintId,treatment:stage.dataset.treatment,visibleSemanticCount:visible.length,visible,duplicateContinuityIds:[...new Set(ids.filter((x,i)=>ids.indexOf(x)!==i))],visibleAnonymousHelperCount:stage.querySelectorAll('[data-helper="true"],[data-role="traveller"],[data-role="item"]').length,cameraTransform:stage.querySelector('.semantic-world')?.style.transform||''}}
window.NexFacelessRenderer={plan,seek:renderAt,probe,duration:plan.duration,ratio:plan.ratio};let qp=new URLSearchParams(location.search);renderAt(qp.has('t')?+qp.get('t'):0);})();